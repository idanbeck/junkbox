rm -f assignment3.zip
cd code
zip assignment3.zip network_utils.py policy_network.py baseline_network.py
mv assignment3.zip ../
cd ../
